class SigalrmException(Exception):
    pass


class ZmqCollectorTimeout(Exception):
    pass
